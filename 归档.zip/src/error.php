<?php

$error_func[1000] = array(
    's' => false,
    'm' => '报错测试'
);

